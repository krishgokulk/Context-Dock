// FileIndexManager.swift
// Context Dock
//
// Spotlight-backed file index. NSMetadataQuery feeds a live in-memory name
// index; no manual file walk, no JSON cache, no "Rebuild Index" button.
// Spotlight is always up-to-date — files appear/disappear automatically.

import Foundation
import AppKit
import Combine

// MARK: - Indexed File Model (kept for SearchResult compatibility)

struct IndexedFile: Codable, Identifiable {
    let id: UUID
    let name: String
    let path: String
    let isDirectory: Bool
    let fileExtension: String
    let parentPath: String
    let modificationDate: Date
    let size: Int64

    var displayName: String { name }

    init(url: URL, attributes: [FileAttributeKey: Any] = [:]) {
        self.id = UUID()
        self.name = url.lastPathComponent
        self.path = url.path
        self.fileExtension = url.pathExtension.lowercased()
        self.parentPath = url.deletingLastPathComponent().path
        self.modificationDate = (attributes[.modificationDate] as? Date) ?? Date()
        self.size = (attributes[.size] as? Int64) ?? 0
        var isDir: ObjCBool = false
        FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir)
        self.isDirectory = isDir.boolValue
    }

    enum CodingKeys: String, CodingKey {
        case id, name, path, isDirectory, fileExtension, parentPath, modificationDate, size
    }
}

// MARK: - Progress / Metadata stubs (keep UI compatibility)

struct IndexMetadata: Codable {
    var lastFullIndexDate: Date?
    var indexedDirectories: [String] = []
    var totalFilesIndexed: Int = 0
    var indexVersion: Int = 1
    static let currentVersion = 1
    init() {}
}

struct IndexingProgress {
    var isIndexing: Bool = false
    var currentDirectory: String = ""
    var filesIndexed: Int = 0
    var totalDirectories: Int = 0
    var processedDirectories: Int = 0
    var lastError: String? = nil
    var progressPercentage: Double { 0 }
}

// MARK: - File Index Manager

@MainActor
final class FileIndexManager: ObservableObject {
    static let shared = FileIndexManager()

    // MARK: Published (UI uses these)
    @Published private(set) var indexedFiles: [IndexedFile] = []
    @Published private(set) var progress = IndexingProgress()
    @Published private(set) var isReady = false
    @Published private(set) var metadata = IndexMetadata()

    // MARK: In-memory name index for fast O(1) prefix lookup
    private var nameIndex: [String: [IndexedFile]] = [:]   // lowercased name prefix → files

    // MARK: NSMetadataQuery — lives on main thread
    private var metadataQuery: NSMetadataQuery?
    private var observers: [NSObjectProtocol] = []

    private init() {}

    // MARK: - Public API

    /// Call once on app launch. Starts the live Spotlight query — no file walk needed.
    func initialize() async {
        guard AppSettings.shared.enableSpotlightSearch else {
            isReady = true
            return
        }
        startSpotlightQuery()
    }

    /// No-op — Spotlight keeps the index fresh automatically. Kept for UI compatibility.
    func forceReindex() async {
        restartQuery()
    }

    /// No-op — there is no JSON cache to clear. Kept for UI compatibility.
    func clearCache() async {
        indexedFiles = []
        nameIndex = [:]
        isReady = false
        restartQuery()
    }

    // MARK: - Search (same signature as before)

    func search(query: String, limit: Int = 50) -> [SearchResult] {
        let q = query.lowercased().trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return [] }

        var seen = Set<String>()
        var scored: [(IndexedFile, Double)] = []

        // 1. Prefix match on indexed names
        let prefix = String(q.prefix(4))
        for (key, files) in nameIndex where key.hasPrefix(prefix) {
            for file in files {
                guard seen.insert(file.path).inserted else { continue }
                if let sc = FuzzyMatcher.score(q, against: file.name.lowercased()) {
                    scored.append((file, sc))
                }
            }
        }

        // 2. Substring fallback for short queries missed by prefix
        if scored.count < limit {
            for (_, files) in nameIndex {
                for file in files {
                    guard seen.insert(file.path).inserted else { continue }
                    let lower = file.name.lowercased()
                    if lower.contains(q) {
                        scored.append((file, 0.4))
                    }
                }
                if scored.count >= limit * 3 { break }
            }
        }

        scored.sort { $0.1 > $1.1 }
        let homeDir = FileManager.default.homeDirectoryForCurrentUser.path
        return scored.prefix(limit).map { (file, _) in
            let icon = NSWorkspace.shared.icon(forFile: file.path)
            icon.size = NSSize(width: 32, height: 32)
            let displayPath = file.path.replacingOccurrences(of: homeDir, with: "~")
            let resultType: SearchResult.ResultType = file.isDirectory ? .folder :
                (file.fileExtension.isEmpty ? .file : .document)
            let url = URL(fileURLWithPath: file.path)
            return SearchResult(
                title: file.name,
                subtitle: displayPath,
                icon: icon,
                action: { NSWorkspace.shared.open(url) },
                type: resultType,
                filePath: file.path,
                contactData: nil
            )
        }
    }

    // MARK: - Spotlight query lifecycle

    private func startSpotlightQuery() {
        let q = NSMetadataQuery()

        // Scope: user home + removable/network volumes
        q.searchScopes = spotlightScopes()

        // Predicate: exclude hidden files and known build/cache dirs
        q.predicate = NSPredicate(
            format: "NOT kMDItemDisplayName BEGINSWITH '.' AND NOT kMDItemPath CONTAINS '/node_modules/' AND NOT kMDItemPath CONTAINS '/DerivedData/' AND NOT kMDItemPath CONTAINS '/Library/Caches/'"
        )

        // Sort by last-used date — most relevant files float up
        q.sortDescriptors = [NSSortDescriptor(key: "kMDItemLastUsedDate", ascending: false)]

        // Cap at 60k items — enough for any user's home folder
        q.operationQueue = .main

        let center = NotificationCenter.default
        observers.append(
            center.addObserver(forName: .NSMetadataQueryDidFinishGathering, object: q, queue: .main) { [weak self] _ in
                self?.ingestResults(from: q)
            }
        )
        observers.append(
            center.addObserver(forName: .NSMetadataQueryDidUpdate, object: q, queue: .main) { [weak self] _ in
                self?.ingestResults(from: q)
            }
        )

        progress.isIndexing = true
        q.start()
        metadataQuery = q
    }

    private func restartQuery() {
        metadataQuery?.stop()
        observers.forEach { NotificationCenter.default.removeObserver($0) }
        observers = []
        metadataQuery = nil
        startSpotlightQuery()
    }

    private func ingestResults(from q: NSMetadataQuery) {
        q.disableUpdates()
        defer { q.enableUpdates() }

        let settings = AppSettings.shared
        let showDocs = settings.enableL1DocumentSearch
        let showFiles = settings.enableL1FileSearch

        var files: [IndexedFile] = []
        files.reserveCapacity(q.resultCount)

        for i in 0 ..< q.resultCount {
            guard let item = q.result(at: i) as? NSMetadataItem else { continue }
            guard let path = item.value(forAttribute: NSMetadataItemPathKey) as? String else { continue }
            let url = URL(fileURLWithPath: path)
            let ext = url.pathExtension.lowercased()

            // Apply document/file filter
            let isDoc = documentExtensions.contains(ext)
            if isDoc && !showDocs { continue }
            if !isDoc && !showFiles { continue }

            // Custom directories filter
            if settings.useCustomSearchDirectories {
                let allowed = settings.searchDirectories.map { $0.path }
                guard !allowed.isEmpty else { continue }
                guard allowed.contains(where: { path.hasPrefix($0) }) else { continue }
            }

            var attrs: [FileAttributeKey: Any] = [:]
            if let size = item.value(forAttribute: NSMetadataItemFSSizeKey) as? Int64 {
                attrs[.size] = size
            }
            if let mod = item.value(forAttribute: NSMetadataItemFSContentChangeDateKey) as? Date {
                attrs[.modificationDate] = mod
            }
            files.append(IndexedFile(url: url, attributes: attrs))
        }

        indexedFiles = files
        buildNameIndex(from: files)

        metadata.lastFullIndexDate = Date()
        metadata.totalFilesIndexed = files.count
        progress.isIndexing = false
        progress.filesIndexed = files.count
        isReady = true
    }

    private func buildNameIndex(from files: [IndexedFile]) {
        var idx: [String: [IndexedFile]] = [:]
        for file in files {
            let key = String(file.name.lowercased().prefix(4))
            idx[key, default: []].append(file)
        }
        nameIndex = idx
    }

    private func spotlightScopes() -> [Any] {
        let settings = AppSettings.shared
        if settings.useCustomSearchDirectories, !settings.searchDirectories.isEmpty {
            return settings.searchDirectories.map { URL(fileURLWithPath: $0.path) }
        }
        return [NSMetadataQueryUserHomeScope]
    }

    private let documentExtensions: Set<String> = [
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
        "pages", "numbers", "key", "txt", "rtf", "md",
        "csv", "json", "xml", "html", "htm", "css", "js",
        "swift", "py", "rb", "go", "java", "c", "cpp", "h"
    ]
}
